"""Predict one sample from the MNIST test dataset."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import torch
from torchvision import datasets
from torchvision.transforms import ToTensor

from mnist_cnn import get_device, load_checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run inference on one MNIST test sample."
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("mnist_cnn_checkpoint.pth"),
    )
    parser.add_argument("--index", type=int, default=0)
    parser.add_argument(
        "--save-figure",
        type=Path,
        default=None,
        help="Optional path for saving the displayed image.",
    )
    parser.add_argument(
        "--no-show",
        action="store_true",
        help="Do not open the Matplotlib window.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = get_device()

    model, _ = load_checkpoint(
        args.checkpoint,
        device,
    )

    test_data = datasets.MNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    if not 0 <= args.index < len(test_data):
        raise IndexError(
            f"Index must be between 0 and {len(test_data) - 1}."
        )

    image, actual_label = test_data[args.index]
    input_tensor = image.unsqueeze(0).to(device)

    with torch.inference_mode():
        logits = model(input_tensor)
        probabilities = torch.softmax(logits, dim=1)
        predicted_label = logits.argmax(dim=1).item()
        confidence = probabilities[0, predicted_label].item()

    print(f"Image shape before batching: {tuple(image.shape)}")
    print(f"Model input shape: {tuple(input_tensor.shape)}")
    print(f"Predicted label: {predicted_label}")
    print(f"Actual label: {actual_label}")
    print(f"Confidence: {confidence:.2%}")

    plt.imshow(image.squeeze(0).numpy(), cmap="gray")
    plt.title(
        f"Predicted: {predicted_label} | "
        f"Actual: {actual_label} | "
        f"Confidence: {confidence:.1%}"
    )
    plt.axis("off")
    plt.tight_layout()

    if args.save_figure is not None:
        args.save_figure.parent.mkdir(
            parents=True,
            exist_ok=True,
        )
        plt.savefig(
            args.save_figure,
            dpi=150,
            bbox_inches="tight",
        )
        print(f"Figure saved to: {args.save_figure.resolve()}")

    if not args.no_show:
        plt.show()
    else:
        plt.close()


if __name__ == "__main__":
    main()
