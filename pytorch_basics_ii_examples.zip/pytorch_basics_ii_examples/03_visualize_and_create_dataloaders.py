"""Visualize an MNIST sample and inspect a mini-batch."""

import matplotlib.pyplot as plt
import torch
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor


BATCH_SIZE = 50


def main() -> None:
    train_data = datasets.MNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )

    test_data = datasets.MNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    train_loader = DataLoader(
        dataset=train_data,
        batch_size=BATCH_SIZE,
        shuffle=True,
    )

    test_loader = DataLoader(
        dataset=test_data,
        batch_size=BATCH_SIZE,
        shuffle=False,
    )

    images, labels = next(iter(train_loader))

    print(f"Number of training batches: {len(train_loader)}")
    print(f"Number of test batches: {len(test_loader)}")
    print(f"Image batch shape: {tuple(images.shape)}")
    print(f"Label batch shape: {tuple(labels.shape)}")
    print(f"Label data type: {labels.dtype}")

    sample_image, sample_label = train_data[0]

    plt.imshow(
        sample_image.squeeze(0).numpy(),
        cmap="gray",
    )
    plt.title(f"Label: {sample_label}")
    plt.axis("off")
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    torch.manual_seed(0)
    main()
