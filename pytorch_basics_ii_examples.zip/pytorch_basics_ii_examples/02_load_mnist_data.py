"""Download the MNIST training and test datasets."""

from torchvision import datasets
from torchvision.transforms import ToTensor


def main() -> None:
    train_data = datasets.MNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )

    test_data = datasets.MNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    print(f"Number of training samples: {len(train_data):,}")
    print(f"Number of test samples: {len(test_data):,}")

    image, label = train_data[0]

    print(f"First image shape: {tuple(image.shape)}")
    print(f"First image data type: {image.dtype}")
    print(f"First label: {label}")


if __name__ == "__main__":
    main()
