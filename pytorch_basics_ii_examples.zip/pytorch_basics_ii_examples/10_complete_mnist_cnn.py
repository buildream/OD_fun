"""Complete MNIST CNN workflow: train, evaluate, save, and infer."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor

from mnist_cnn import CNN, get_device, load_checkpoint, save_checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run the complete PyTorch Basics II workflow."
    )
    parser.add_argument("--batch-size", type=int, default=50)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("mnist_cnn_checkpoint.pth"),
    )
    return parser.parse_args()


def train_one_epoch(
    model: nn.Module,
    dataloader: DataLoader,
    optimizer: torch.optim.Optimizer,
    loss_fn: nn.Module,
    device: torch.device,
) -> float:
    model.train()

    total_loss = 0.0
    sample_count = 0

    for images, labels in dataloader:
        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad(set_to_none=True)
        logits = model(images)
        loss = loss_fn(logits, labels)
        loss.backward()
        optimizer.step()

        total_loss += loss.item() * images.size(0)
        sample_count += images.size(0)

    return total_loss / sample_count


def evaluate(
    model: nn.Module,
    dataloader: DataLoader,
    loss_fn: nn.Module,
    device: torch.device,
) -> tuple[float, float]:
    model.eval()

    total_loss = 0.0
    correct = 0
    sample_count = 0

    with torch.inference_mode():
        for images, labels in dataloader:
            images = images.to(device)
            labels = labels.to(device)

            logits = model(images)
            loss = loss_fn(logits, labels)

            total_loss += loss.item() * images.size(0)
            correct += (
                logits.argmax(dim=1) == labels
            ).sum().item()
            sample_count += images.size(0)

    return (
        total_loss / sample_count,
        100.0 * correct / sample_count,
    )


def main() -> None:
    args = parse_args()
    torch.manual_seed(42)

    device = get_device()
    print(f"Using device: {device}")

    train_data = datasets.MNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )

    test_data = datasets.MNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    train_loader = DataLoader(
        train_data,
        batch_size=args.batch_size,
        shuffle=True,
        pin_memory=device.type == "cuda",
    )

    test_loader = DataLoader(
        test_data,
        batch_size=args.batch_size,
        shuffle=False,
        pin_memory=device.type == "cuda",
    )

    model = CNN().to(device)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=args.learning_rate,
    )

    for epoch in range(1, args.epochs + 1):
        train_loss = train_one_epoch(
            model,
            train_loader,
            optimizer,
            loss_fn,
            device,
        )

        test_loss, accuracy = evaluate(
            model,
            test_loader,
            loss_fn,
            device,
        )

        print(
            f"Epoch {epoch:02d}/{args.epochs:02d} | "
            f"Train loss: {train_loss:.4f} | "
            f"Test loss: {test_loss:.4f} | "
            f"Accuracy: {accuracy:.2f}%"
        )

    save_checkpoint(
        args.checkpoint,
        model,
        optimizer=optimizer,
        epoch=args.epochs,
        metadata={
            "batch_size": args.batch_size,
            "learning_rate": args.learning_rate,
        },
    )

    print(f"Saved checkpoint: {args.checkpoint.resolve()}")

    loaded_model, _ = load_checkpoint(
        args.checkpoint,
        device,
    )

    image, actual_label = test_data[0]
    input_tensor = image.unsqueeze(0).to(device)

    with torch.inference_mode():
        logits = loaded_model(input_tensor)
        predicted_label = logits.argmax(dim=1).item()

    print(
        f"First test sample | "
        f"Predicted: {predicted_label} | "
        f"Actual: {actual_label}"
    )


if __name__ == "__main__":
    main()
