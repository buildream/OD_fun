"""Shared CNN model and utility functions for the PyTorch Basics II examples."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch import nn


class CNN(nn.Module):
    """A convolutional neural network for 28 x 28 grayscale MNIST images."""

    def __init__(self) -> None:
        super().__init__()

        self.conv1 = nn.Conv2d(
            in_channels=1,
            out_channels=32,
            kernel_size=3,
            stride=1,
        )
        self.conv2 = nn.Conv2d(
            in_channels=32,
            out_channels=64,
            kernel_size=3,
            stride=1,
        )

        self.dropout1 = nn.Dropout2d(p=0.25)
        self.dropout2 = nn.Dropout(p=0.5)

        # Shape calculation:
        # 28 -> Conv3 -> 26 -> Conv3 -> 24 -> MaxPool2 -> 12
        # 64 channels x 12 x 12 = 9,216 features
        self.fc1 = nn.Linear(64 * 12 * 12, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        x = torch.max_pool2d(x, kernel_size=2)
        x = self.dropout1(x)

        x = torch.flatten(x, start_dim=1)
        x = torch.relu(self.fc1(x))
        x = self.dropout2(x)

        # Return raw logits.
        # CrossEntropyLoss applies log-softmax internally.
        return self.fc2(x)


def get_device() -> torch.device:
    """Select CUDA, Apple MPS, or CPU in that order."""
    if torch.cuda.is_available():
        return torch.device("cuda")

    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")

    return torch.device("cpu")


def save_checkpoint(
    path: str | Path,
    model: nn.Module,
    *,
    optimizer: torch.optim.Optimizer | None = None,
    epoch: int | None = None,
    metadata: dict[str, Any] | None = None,
) -> Path:
    """Save model parameters and optional training information."""
    checkpoint_path = Path(path)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)

    checkpoint: dict[str, Any] = {
        "model_state_dict": model.state_dict(),
        "epoch": epoch,
        "metadata": metadata or {},
    }

    if optimizer is not None:
        checkpoint["optimizer_state_dict"] = optimizer.state_dict()

    torch.save(checkpoint, checkpoint_path)
    return checkpoint_path


def load_checkpoint(
    path: str | Path,
    device: torch.device,
) -> tuple[CNN, dict[str, Any]]:
    """Load a CNN model from a state-dict checkpoint."""
    checkpoint_path = Path(path)

    if not checkpoint_path.exists():
        raise FileNotFoundError(
            f"Checkpoint not found: {checkpoint_path}\n"
            "Run 05_train_and_save_model.py first."
        )

    # weights_only=True is safer for state-dict checkpoints in recent PyTorch.
    # The fallback keeps compatibility with older PyTorch versions.
    try:
        checkpoint = torch.load(
            checkpoint_path,
            map_location=device,
            weights_only=True,
        )
    except TypeError:
        checkpoint = torch.load(
            checkpoint_path,
            map_location=device,
        )

    model = CNN().to(device)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    return model, checkpoint
