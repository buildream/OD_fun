"""Check the PyTorch environment and display the tutorial hyperparameters."""

import torch

from mnist_cnn import get_device


BATCH_SIZE = 50
LEARNING_RATE = 0.0001
EPOCHS = 15


def main() -> None:
    device = get_device()

    print(f"PyTorch version: {torch.__version__}")
    print(f"Selected device: {device}")
    print(f"CUDA available: {torch.cuda.is_available()}")

    if torch.cuda.is_available():
        print(f"CUDA device name: {torch.cuda.get_device_name(0)}")

    print("\nTutorial hyperparameters")
    print(f"Batch size: {BATCH_SIZE}")
    print(f"Learning rate: {LEARNING_RATE}")
    print(f"Number of epochs: {EPOCHS}")


if __name__ == "__main__":
    main()
