"""Create the CNN model and check its output with a dummy input."""

import torch

from mnist_cnn import CNN, get_device


def main() -> None:
    device = get_device()
    model = CNN().to(device)

    dummy_input = torch.randn(
        4,
        1,
        28,
        28,
        device=device,
    )

    model.eval()

    with torch.inference_mode():
        logits = model(dummy_input)
        probabilities = torch.softmax(logits, dim=1)

    parameter_count = sum(
        parameter.numel()
        for parameter in model.parameters()
        if parameter.requires_grad
    )

    print(f"Device: {device}")
    print(model)
    print(f"\nTrainable parameters: {parameter_count:,}")
    print(f"Input shape: {tuple(dummy_input.shape)}")
    print(f"Output shape: {tuple(logits.shape)}")
    print(
        "Probability sum for the first sample: "
        f"{probabilities[0].sum().item():.6f}"
    )


if __name__ == "__main__":
    main()
