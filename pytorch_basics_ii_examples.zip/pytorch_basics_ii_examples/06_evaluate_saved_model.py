"""Load a saved MNIST CNN checkpoint and evaluate it."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor

from mnist_cnn import get_device, load_checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate a saved MNIST CNN."
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("mnist_cnn_checkpoint.pth"),
    )
    parser.add_argument("--batch-size", type=int, default=50)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    device = get_device()

    model, checkpoint = load_checkpoint(
        args.checkpoint,
        device,
    )

    test_data = datasets.MNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    test_loader = DataLoader(
        test_data,
        batch_size=args.batch_size,
        shuffle=False,
        pin_memory=device.type == "cuda",
    )

    loss_fn = nn.CrossEntropyLoss()

    total_loss = 0.0
    correct = 0

    with torch.inference_mode():
        for images, labels in test_loader:
            images = images.to(device)
            labels = labels.to(device)

            logits = model(images)
            total_loss += (
                loss_fn(logits, labels).item()
                * images.size(0)
            )
            correct += (
                logits.argmax(dim=1) == labels
            ).sum().item()

    average_loss = total_loss / len(test_data)
    accuracy = 100.0 * correct / len(test_data)

    print(f"Device: {device}")
    print(f"Checkpoint epoch: {checkpoint.get('epoch')}")
    print(f"Average test loss: {average_loss:.4f}")
    print(f"Test accuracy: {accuracy:.2f}%")


if __name__ == "__main__":
    main()
