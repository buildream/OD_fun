"""Classify a handwritten digit from a webcam region of interest."""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np
import torch
from PIL import Image, ImageOps
from torchvision import transforms

from mnist_cnn import get_device, load_checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run MNIST digit inference using a webcam."
    )
    parser.add_argument("--camera", type=int, default=0)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("mnist_cnn_checkpoint.pth"),
    )
    parser.add_argument(
        "--invert",
        action="store_true",
        help=(
            "Invert the ROI. Enable this when the digit is darker "
            "than the background."
        ),
    )
    return parser.parse_args()


def make_transform() -> transforms.Compose:
    return transforms.Compose(
        [
            transforms.Resize(
                size=(28, 28),
                antialias=True,
            ),
            transforms.ToTensor(),
        ]
    )


def classify_roi(
    roi: np.ndarray,
    model: torch.nn.Module,
    device: torch.device,
    transform: transforms.Compose,
    invert: bool,
) -> tuple[int, float]:
    image = Image.fromarray(roi).convert("L")

    if invert:
        image = ImageOps.invert(image)

    input_tensor = transform(image).unsqueeze(0).to(device)

    with torch.inference_mode():
        logits = model(input_tensor)
        probabilities = torch.softmax(logits, dim=1)
        predicted_label = logits.argmax(dim=1).item()
        confidence = probabilities[0, predicted_label].item()

    return predicted_label, confidence


def main() -> None:
    args = parse_args()
    device = get_device()

    model, _ = load_checkpoint(
        args.checkpoint,
        device,
    )
    transform = make_transform()

    camera = cv2.VideoCapture(args.camera)

    if not camera.isOpened():
        raise RuntimeError(
            f"Could not open camera index {args.camera}."
        )

    prediction_text = "Press SPACE to classify"

    print("Controls:")
    print("  SPACE: classify the center region")
    print("  Q or ESC: quit")

    try:
        while True:
            success, frame = camera.read()

            if not success:
                print("Failed to read a camera frame.")
                break

            height, width = frame.shape[:2]
            roi_size = int(min(height, width) * 0.55)

            center_x = width // 2
            center_y = height // 2

            x1 = center_x - roi_size // 2
            y1 = center_y - roi_size // 2
            x2 = x1 + roi_size
            y2 = y1 + roi_size

            cv2.rectangle(
                frame,
                (x1, y1),
                (x2, y2),
                (255, 255, 255),
                2,
            )

            cv2.putText(
                frame,
                prediction_text,
                (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )

            cv2.imshow("MNIST Camera Inference", frame)

            key = cv2.waitKey(1) & 0xFF

            if key in (ord("q"), 27):
                break

            if key == 32:
                grayscale = cv2.cvtColor(
                    frame,
                    cv2.COLOR_BGR2GRAY,
                )
                roi = grayscale[y1:y2, x1:x2]

                predicted_label, confidence = classify_roi(
                    roi,
                    model,
                    device,
                    transform,
                    args.invert,
                )

                prediction_text = (
                    f"Prediction: {predicted_label} "
                    f"({confidence:.1%})"
                )
                print(prediction_text)

    finally:
        camera.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
