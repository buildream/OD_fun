"""Train the MNIST CNN and save a state-dict checkpoint."""

from __future__ import annotations

import argparse
import random
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor

from mnist_cnn import CNN, get_device, save_checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train a CNN on the MNIST dataset."
    )
    parser.add_argument("--batch-size", type=int, default=50)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("mnist_cnn_checkpoint.pth"),
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--log-interval",
        type=int,
        default=200,
        help="Print the loss every N training batches.",
    )
    return parser.parse_args()


def train_one_epoch(
    dataloader: DataLoader,
    model: nn.Module,
    loss_fn: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    epoch: int,
    log_interval: int,
) -> float:
    model.train()

    running_loss = 0.0
    sample_count = 0

    for batch_index, (images, labels) in enumerate(dataloader, start=1):
        images = images.to(device)
        labels = labels.to(device)

        optimizer.zero_grad(set_to_none=True)

        logits = model(images)
        loss = loss_fn(logits, labels)

        loss.backward()
        optimizer.step()

        batch_size = images.size(0)
        running_loss += loss.item() * batch_size
        sample_count += batch_size

        if batch_index % log_interval == 0:
            print(
                f"Epoch {epoch:02d} | "
                f"Batch {batch_index:04d}/{len(dataloader):04d} | "
                f"Loss {loss.item():.4f}"
            )

    return running_loss / sample_count


def evaluate(
    dataloader: DataLoader,
    model: nn.Module,
    loss_fn: nn.Module,
    device: torch.device,
) -> tuple[float, float]:
    model.eval()

    total_loss = 0.0
    correct = 0
    sample_count = 0

    with torch.inference_mode():
        for images, labels in dataloader:
            images = images.to(device)
            labels = labels.to(device)

            logits = model(images)
            loss = loss_fn(logits, labels)

            batch_size = images.size(0)
            total_loss += loss.item() * batch_size
            correct += (
                logits.argmax(dim=1) == labels
            ).sum().item()
            sample_count += batch_size

    average_loss = total_loss / sample_count
    accuracy = 100.0 * correct / sample_count

    return average_loss, accuracy


def main() -> None:
    args = parse_args()

    random.seed(args.seed)
    torch.manual_seed(args.seed)

    device = get_device()
    print(f"Using device: {device}")

    train_data = datasets.MNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )

    test_data = datasets.MNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    train_loader = DataLoader(
        train_data,
        batch_size=args.batch_size,
        shuffle=True,
        pin_memory=device.type == "cuda",
    )

    test_loader = DataLoader(
        test_data,
        batch_size=args.batch_size,
        shuffle=False,
        pin_memory=device.type == "cuda",
    )

    model = CNN().to(device)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=args.learning_rate,
    )

    for epoch in range(1, args.epochs + 1):
        train_loss = train_one_epoch(
            train_loader,
            model,
            loss_fn,
            optimizer,
            device,
            epoch,
            args.log_interval,
        )

        test_loss, accuracy = evaluate(
            test_loader,
            model,
            loss_fn,
            device,
        )

        print(
            f"Epoch {epoch:02d}/{args.epochs:02d} completed | "
            f"Train loss: {train_loss:.4f} | "
            f"Test loss: {test_loss:.4f} | "
            f"Accuracy: {accuracy:.2f}%"
        )

    checkpoint_path = save_checkpoint(
        args.checkpoint,
        model,
        optimizer=optimizer,
        epoch=args.epochs,
        metadata={
            "batch_size": args.batch_size,
            "learning_rate": args.learning_rate,
            "epochs": args.epochs,
            "dataset": "MNIST",
        },
    )

    print(f"\nCheckpoint saved to: {checkpoint_path.resolve()}")


if __name__ == "__main__":
    main()
