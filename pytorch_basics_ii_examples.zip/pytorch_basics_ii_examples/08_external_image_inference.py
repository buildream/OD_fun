"""Run MNIST inference on an external image file."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
from PIL import Image, ImageOps
from torchvision import transforms

from mnist_cnn import get_device, load_checkpoint


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Classify an external handwritten-digit image."
    )
    parser.add_argument(
        "image",
        type=Path,
        help="Path to a handwritten-digit image.",
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("mnist_cnn_checkpoint.pth"),
    )
    parser.add_argument(
        "--invert",
        action="store_true",
        help=(
            "Invert the grayscale image. Use this when the source has "
            "a dark digit on a bright background."
        ),
    )
    parser.add_argument(
        "--target",
        type=int,
        default=None,
        choices=range(10),
        help="Optional expected digit used for a correctness check.",
    )
    return parser.parse_args()


def prepare_image(
    image_path: Path,
    invert: bool,
) -> tuple[Image.Image, torch.Tensor]:
    if not image_path.exists():
        raise FileNotFoundError(f"Image not found: {image_path}")

    image = Image.open(image_path).convert("L")

    if invert:
        image = ImageOps.invert(image)

    transform = transforms.Compose(
        [
            transforms.Resize(
                size=(28, 28),
                antialias=True,
            ),
            transforms.ToTensor(),
        ]
    )

    tensor = transform(image).unsqueeze(0)

    return image, tensor


def main() -> None:
    args = parse_args()
    device = get_device()

    model, _ = load_checkpoint(
        args.checkpoint,
        device,
    )

    _, input_tensor = prepare_image(
        args.image,
        args.invert,
    )
    input_tensor = input_tensor.to(device)

    with torch.inference_mode():
        logits = model(input_tensor)
        probabilities = torch.softmax(logits, dim=1)
        predicted_label = logits.argmax(dim=1).item()
        confidence = probabilities[0, predicted_label].item()

    print(f"Predicted digit: {predicted_label}")
    print(f"Confidence: {confidence:.2%}")

    if args.target is not None:
        if predicted_label == args.target:
            print(f"Correct: the prediction is {args.target}.")
        else:
            print(
                f"Incorrect: expected {args.target}, "
                f"but predicted {predicted_label}."
            )


if __name__ == "__main__":
    main()
