"""Train a FashionMNIST classifier and save its state dictionary."""

from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor


MODEL_PATH = Path("model.pth")


class NeuralNetwork(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28 * 28, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 10),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear_relu_stack(self.flatten(x))


def select_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def train_one_epoch(
    dataloader: DataLoader,
    model: nn.Module,
    loss_fn: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: str,
) -> None:
    model.train()

    for batch, (features, labels) in enumerate(dataloader):
        features = features.to(device)
        labels = labels.to(device)

        predictions = model(features)
        loss = loss_fn(predictions, labels)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        if batch % 100 == 0:
            print(f"Batch {batch:>4d} | loss: {loss.item():>7f}")


def main() -> None:
    training_data = datasets.FashionMNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )
    train_dataloader = DataLoader(training_data, batch_size=64)

    device = select_device()
    print(f"Using {device} device")

    model = NeuralNetwork().to(device)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=1e-3)

    # Five epochs match the quickstart tutorial.
    for epoch in range(5):
        print(f"Epoch {epoch + 1}\n-------------------------------")
        train_one_epoch(train_dataloader, model, loss_fn, optimizer, device)

    # Save only the learned model parameters.
    torch.save(model.state_dict(), MODEL_PATH)
    print(f"Saved PyTorch model state to: {MODEL_PATH.resolve()}")


if __name__ == "__main__":
    main()
