"""Download the FashionMNIST training and test datasets.

Based on the PyTorch Quickstart tutorial:
https://tutorials.pytorch.kr/beginner/basics/quickstart_tutorial.html
"""

from torchvision import datasets
from torchvision.transforms import ToTensor


def main() -> None:
    # Download the training dataset from the public repository.
    training_data = datasets.FashionMNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )

    # Download the test dataset from the public repository.
    test_data = datasets.FashionMNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    print(f"Number of training samples: {len(training_data)}")
    print(f"Number of test samples: {len(test_data)}")

    image, label = training_data[0]
    print(f"First image shape: {image.shape}")
    print(f"First label: {label}")


if __name__ == "__main__":
    main()
