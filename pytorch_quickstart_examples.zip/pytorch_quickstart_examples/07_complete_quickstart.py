"""Complete FashionMNIST quickstart workflow in one Python file."""

from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor


MODEL_PATH = Path("model.pth")
CLASSES = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot",
]


class NeuralNetwork(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28 * 28, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 10),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear_relu_stack(self.flatten(x))


def select_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def train(
    dataloader: DataLoader,
    model: nn.Module,
    loss_fn: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: str,
) -> None:
    size = len(dataloader.dataset)
    model.train()

    for batch, (features, labels) in enumerate(dataloader):
        features = features.to(device)
        labels = labels.to(device)

        predictions = model(features)
        loss = loss_fn(predictions, labels)

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

        if batch % 100 == 0:
            current = (batch + 1) * len(features)
            print(f"loss: {loss.item():>7f}  [{current:>5d}/{size:>5d}]")


def test(
    dataloader: DataLoader,
    model: nn.Module,
    loss_fn: nn.Module,
    device: str,
) -> None:
    size = len(dataloader.dataset)
    num_batches = len(dataloader)
    model.eval()

    test_loss = 0.0
    correct = 0.0

    with torch.no_grad():
        for features, labels in dataloader:
            features = features.to(device)
            labels = labels.to(device)

            predictions = model(features)
            test_loss += loss_fn(predictions, labels).item()
            correct += (
                (predictions.argmax(dim=1) == labels)
                .type(torch.float)
                .sum()
                .item()
            )

    test_loss /= num_batches
    correct /= size

    print(
        "Test Error:\n"
        f" Accuracy: {(100 * correct):>0.1f}%, "
        f"Avg loss: {test_loss:>8f}\n"
    )


def main() -> None:
    training_data = datasets.FashionMNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )
    test_data = datasets.FashionMNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    train_dataloader = DataLoader(training_data, batch_size=64)
    test_dataloader = DataLoader(test_data, batch_size=64)

    device = select_device()
    print(f"Using {device} device")

    model = NeuralNetwork().to(device)
    loss_fn = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=1e-3)

    for epoch in range(5):
        print(f"Epoch {epoch + 1}\n-------------------------------")
        train(train_dataloader, model, loss_fn, optimizer, device)
        test(test_dataloader, model, loss_fn, device)

    torch.save(model.state_dict(), MODEL_PATH)
    print(f"Saved PyTorch model state to: {MODEL_PATH.resolve()}")

    # Demonstrate loading the saved state into a newly created model.
    loaded_model = NeuralNetwork().to(device)
    state_dict = torch.load(MODEL_PATH, map_location=device, weights_only=True)
    loaded_model.load_state_dict(state_dict)
    loaded_model.eval()

    image, label = test_data[0]
    with torch.no_grad():
        prediction = loaded_model(image.to(device))
        predicted_class = CLASSES[prediction[0].argmax(dim=0).item()]
        actual_class = CLASSES[label]

    print(f'Predicted: "{predicted_class}", Actual: "{actual_class}"')


if __name__ == "__main__":
    main()
