"""Create DataLoader objects and inspect one batch."""

from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor


def main() -> None:
    training_data = datasets.FashionMNIST(
        root="data",
        train=True,
        download=True,
        transform=ToTensor(),
    )

    test_data = datasets.FashionMNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    batch_size = 64

    # Wrap each dataset in an iterable DataLoader.
    train_dataloader = DataLoader(training_data, batch_size=batch_size)
    test_dataloader = DataLoader(test_data, batch_size=batch_size)

    print(f"Number of training batches: {len(train_dataloader)}")
    print(f"Number of test batches: {len(test_dataloader)}")

    # Inspect the first test batch.
    for features, labels in test_dataloader:
        print(f"Shape of features [N, C, H, W]: {features.shape}")
        print(f"Shape of labels: {labels.shape}")
        print(f"Label data type: {labels.dtype}")
        break


if __name__ == "__main__":
    main()
