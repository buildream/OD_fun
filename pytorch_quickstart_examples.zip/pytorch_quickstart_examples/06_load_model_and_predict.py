"""Load a saved FashionMNIST model and predict one test image."""

from pathlib import Path

import torch
from torch import nn
from torchvision import datasets
from torchvision.transforms import ToTensor


MODEL_PATH = Path("model.pth")

CLASSES = [
    "T-shirt/top",
    "Trouser",
    "Pullover",
    "Dress",
    "Coat",
    "Sandal",
    "Shirt",
    "Sneaker",
    "Bag",
    "Ankle boot",
]


class NeuralNetwork(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28 * 28, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 10),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear_relu_stack(self.flatten(x))


def select_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def main() -> None:
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "model.pth was not found. Run 05_train_and_save_model.py first."
        )

    device = select_device()
    print(f"Using {device} device")

    test_data = datasets.FashionMNIST(
        root="data",
        train=False,
        download=True,
        transform=ToTensor(),
    )

    # Recreate the same model architecture before loading its parameters.
    model = NeuralNetwork().to(device)
    state_dict = torch.load(MODEL_PATH, map_location=device, weights_only=True)
    model.load_state_dict(state_dict)
    model.eval()

    image, label = test_data[0]

    with torch.no_grad():
        image = image.to(device)
        prediction = model(image)
        predicted_class = CLASSES[prediction[0].argmax(dim=0).item()]
        actual_class = CLASSES[label]

    print(f'Predicted: "{predicted_class}", Actual: "{actual_class}"')


if __name__ == "__main__":
    main()
