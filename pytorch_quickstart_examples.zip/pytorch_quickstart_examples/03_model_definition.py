"""Define the neural network used in the FashionMNIST quickstart."""

import torch
from torch import nn


def select_device() -> str:
    """Select CUDA, MPS, or CPU in that order."""
    if torch.cuda.is_available():
        return "cuda"
    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


class NeuralNetwork(nn.Module):
    """A fully connected classifier for 28 x 28 grayscale images."""

    def __init__(self) -> None:
        super().__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28 * 28, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 10),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.flatten(x)
        logits = self.linear_relu_stack(x)
        return logits


def main() -> None:
    device = select_device()
    print(f"Using {device} device")

    model = NeuralNetwork().to(device)
    print(model)

    # Run one artificial batch through the network.
    sample_batch = torch.rand(64, 1, 28, 28, device=device)
    logits = model(sample_batch)
    print(f"Output shape: {logits.shape}")


if __name__ == "__main__":
    main()
